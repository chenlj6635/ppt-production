# Sponsors and User Benefits

English | [中文](SPONSORS_CN.md)

PPT Master is free and open source. The sponsors below help fund its ongoing maintenance and provide optional benefits for PPT Master users. Sponsorship does not change the project's provider-agnostic design: use any compatible agent, model, or service you prefer.

Want to support the project or discuss a partnership? See the [sponsorship guide](https://github.com/hugohe3/ppt-master/blob/main/SPONSORING.md).

## Current Model Recommendation

For the best results, use **[Kimi K3](https://www.kimi.com/code/?aff=ppt-master)** (or Claude) to drive the workflow, paired with **`gpt-image-2.5-sunburst`** (OpenAI) or **`gemini-nano-banana-2.1`** (Google) for AI image generation. If model capability is limiting output quality, upgrade the driving model before weakening the workflow or its quality requirements.

## Kimi

<p align="center">
  <a href="https://www.kimi.com/code/?aff=ppt-master"><img src="https://gcdn.moonshot.cn/growth-cdn/sponsor/kimi-en.png" alt="Kimi" width="100%"></a>
</p>

Thanks to [Kimi](https://www.kimi.com/code/?aff=ppt-master) for sponsoring PPT Master. [Kimi K3](https://platform.kimi.ai/docs/guide/kimi-k3-quickstart) is the world's first open 3T-class model, featuring native vision and a 1-million-token context window. With PPT Master, K3 can understand PDFs, DOCX files, web pages, and other source material, structure the narrative, and generate a natively editable PPTX.

**Try a [Kimi Code plan](https://www.kimi.com/code/?aff=ppt-master) ([中文站](https://www.kimi.com/code/?aff=ppt-master) | [Global](https://www.kimi.ai/code/?aff=ppt-master)), or access the API through the Kimi Open Platform ([中文站](https://platform.kimi.com?aff=ppt-master) | [Global](https://platform.kimi.ai?aff=ppt-master)).**

## Model Access Partners

### PackyCode

<a href="https://www.packyapi.ai/register?aff=ppt-master"><img src="https://raw.githubusercontent.com/hugohe3/ppt-master/main/docs/assets/sponsors/packycode.png" alt="PackyCode" width="150"></a>

[PackyCode](https://www.packyapi.ai/register?aff=ppt-master) provides relay access to Claude Code, Codex, Gemini, and other services. Register through the dedicated link and enter the promo code **`ppt-master`** during recharge to receive 10% off.

### APIKEY.FAN

<a href="https://apikey.fan/register?aff=PPT-MASTER"><img src="https://raw.githubusercontent.com/hugohe3/ppt-master/main/docs/assets/sponsors/apikey-fan.png" alt="APIKEY.FAN" width="150"></a>

[APIKEY.FAN](https://apikey.fan/register?aff=PPT-MASTER) provides enterprise-grade access to Claude, OpenAI, Gemini, and other mainstream models. Register through the dedicated link to receive up to a permanent 5% discount on top-ups.

### RunAPI

<a href="https://runapi.host/register?aff=WMLJ"><img src="https://raw.githubusercontent.com/hugohe3/ppt-master/main/docs/assets/sponsors/runapi.png" alt="RunAPI" width="150"></a>

[RunAPI](https://runapi.host/register?aff=WMLJ) provides access to 150+ models, including OpenAI, Claude, Gemini, DeepSeek, and Grok, through one API key. Register through the dedicated link and contact an administrator to claim **¥7 in free credit**.

### ModelGo

<a href="https://modelgo.ai/?utm_source=ppt-master&amp;utm_medium=sponsorship&amp;utm_content=readme02&amp;campaign_id=ppt-master-github&amp;ad_group_id=readme02"><img src="https://raw.githubusercontent.com/hugohe3/ppt-master/main/docs/assets/sponsors/modelgo.svg" alt="ModelGo" width="150"></a>

Thanks to ModelGo for sponsoring this project! ModelGo is a stable, efficient enterprise-grade AI API aggregation platform. A single API Key gives you access to leading AI models including Claude, OpenAI, Gemini, and DeepSeek, helping developers and businesses build AI applications quickly at lower cost. ModelGo offers an exclusive perk for PPT Master users: get $0.5 in trial credit on sign-up, another $2 after your first API call, and an extra $1 for inviting new users! The platform also offers a tiered spending rebate: the more you use, the more you get back, so you can enjoy AI model calls to the fullest. In addition, ModelGo supports enterprise-grade features such as SLA service guarantees and visual monitoring dashboards, keeping API calls stable and reliable for production deployments. Visit the [ModelGo website](https://modelgo.ai/?utm_source=ppt-master&utm_medium=sponsorship&utm_content=readme02&campaign_id=ppt-master-github&ad_group_id=readme02) to sign up and start building AI efficiently!

## Infrastructure Support

<a href="https://m.do.co/c/547f129aabe1"><img src="https://opensource.nyc3.cdn.digitaloceanspaces.com/attribution/assets/PoweredByDO/DO_Powered_by_Badge_blue.svg" alt="Powered by DigitalOcean" height="40"></a>

Thanks to [DigitalOcean](https://m.do.co/c/547f129aabe1) for supporting the project's infrastructure.

## Individual Support

If PPT Master has been useful to you, individual support of any amount helps keep the project moving and free.

<a href="https://paypal.me/hugohe3"><img src="https://img.shields.io/badge/PayPal-Sponsor-00457C?style=for-the-badge&logo=paypal&logoColor=white" alt="Sponsor via PayPal"></a>

[Alipay QR code](https://raw.githubusercontent.com/hugohe3/ppt-master/main/docs/assets/alipay-qr.jpg)
